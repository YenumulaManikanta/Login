package com.miscot.loginController;


import javax.websocket.server.PathParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;

import com.miscot.login.ForgotPassword;
import com.miscot.login.Login;
import com.miscot.login.ResetPwd;
import com.miscot.service.LoginService;
import com.miscot.service.LoginServiceImpl;

@Path("ResetPasswordCnt")
public class ResetPasswordCnt {
	@Autowired
	LoginService service;
	@Autowired
	LoginServiceImpl loginServiceimpl;
	
	@GET
	@Path("/id{userId}/pwd{password}")
    @Produces(MediaType.APPLICATION_JSON)
	public Login getbylogin( @PathParam ("userId") String userId, @PathParam ("password")String password ) {
		Login log=new Login();
    	log.getUserId();
    	log.getPassword();
    	
    	return log;
}
	@GET
	@Path("/name{Name}/age{Age}/phno{PhNo}/email{Email}")
	@Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
	public ForgotPassword forgotPassword( @PathParam ("name") String Name, @PathParam ("age")String Age,
			@PathParam ("phno") String PhNo, @PathParam ("email")String Email){
		ForgotPassword forgotPwd=new ForgotPassword();
		forgotPwd.getName();
		forgotPwd.getAge();
		forgotPwd.getPhno();
		forgotPwd.getEmail();
		
    	return forgotPwd;
}
	@POST
	@Path("/ResetPassword")
	@Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
	public <ResetPassword> ResetPassword resetPassword(@RequestBody ResetPassword resetPassword ){
		
		String newPassword = "";
		String confirmPassword = "";
		if(newPassword!=confirmPassword) {
			System.out.println("enter correct password");
		}else {
			System.out.println("success");
		}
		return resetPassword;
	}
}
