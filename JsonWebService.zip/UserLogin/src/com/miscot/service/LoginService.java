package com.miscot.service;

import java.sql.SQLException;

import com.miscot.login.ForgotPassword;
import com.miscot.login.Login;
import com.miscot.login.ResetPwd;

public interface LoginService {
	
	public Login login(String userId, String password) throws SQLException;
	public ForgotPassword forgotpassword(String name, String age, String phno, String email) throws Exception;
	public ResetPwd resetPassword(String newPassword, String confirmPassword) throws SQLException;

}
