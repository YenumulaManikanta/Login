package com.miscot.service;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;
import javax.ws.rs.Path;

import org.springframework.beans.factory.annotation.Autowired;

import com.miscot.login.ForgotPassword;
import com.miscot.login.Login;
import com.miscot.login.ResetPwd;
@Path("LoginServiceImpl")
public class LoginServiceImpl implements LoginService {

	@Autowired
	 private DataSource dataSource;
	@Override
	public Login login(String userId, String password) throws SQLException {
		List<Login> list=new ArrayList<>();
		Connection connection=dataSource.getConnection();
		 Statement statement=(Statement) connection.createStatement();
		ResultSet resultSet=((java.sql.Statement) statement).executeQuery("select * from user where id="+userId);
		while(resultSet.next()) {
			Login log=new Login();
			log.setUserId(resultSet.getString("msdhoni"));
			log.setPassword(resultSet.getString("123456"));
			list.add(log);
			
			return log;
		}
		return null;
	}
	@Override
	public ForgotPassword forgotpassword(String name, String age, String phno, String email) throws SQLException {
		
		Connection connection=dataSource.getConnection();
		 Statement statement=(Statement) connection.createStatement();
		ResultSet resultSet=((java.sql.Statement) statement).executeQuery("select * from user where name="+name
				+"age="+age+"phno="+phno+"email="+email );
		while(resultSet.next()) {
			ForgotPassword fgp=new ForgotPassword();
			fgp.setName("msdhoni");
			fgp.setAge("35");
			fgp.setPhno("9989121418");
			fgp.setEmail("dhoni@gmail.com");
			return fgp;}
		// TODO Auto-generated method stub
		
		return null;
	}

	@Override
	public ResetPwd resetPassword(String newPassword, String  confirmPassword) throws SQLException {
		// TODO Auto-generated method stub
		Connection connection=dataSource.getConnection();
		 Statement statement=(Statement) connection.createStatement();
		ResultSet resultSet=((java.sql.Statement) statement).executeQuery("insert into user values(?,?)");
		while(resultSet.next()) {
		ResetPwd rp=new ResetPwd(newPassword, confirmPassword);
		rp.setNewPassword("msd@123");
		rp.setConfirmPassword("msd@123");
		if(newPassword.equals(confirmPassword)) {
			System.out.println("continue");
		}
		return rp;
	}
		return null;
}
}